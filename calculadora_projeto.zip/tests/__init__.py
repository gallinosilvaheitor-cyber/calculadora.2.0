"""Pacote de testes unitários da calculadora."""
