"""
Testes unitários para a calculadora em Python.
Cobre operações básicas, tratamentos de erro, memória, histórico e avaliação sintática (AST).
"""

import math
import unittest

from calculadora.core import (
    Calculator,
    CalculatorError,
    add,
    divide,
    modulo,
    multiply,
    percentage,
    power,
    square_root,
    subtract,
)
from calculadora.parser import SafeEvaluator


class TestCoreOperations(unittest.TestCase):
    """Testes para as funções matemáticas puras."""

    def test_basic_operations(self):
        self.assertEqual(add(10, 5), 15)
        self.assertEqual(subtract(20, 8), 12)
        self.assertEqual(multiply(6, 7), 42)
        self.assertEqual(divide(100, 4), 25)
        self.assertEqual(divide(7, 2), 3.5)

    def test_divide_by_zero(self):
        with self.assertRaises(CalculatorError):
            divide(10, 0)

    def test_modulo(self):
        self.assertEqual(modulo(10, 3), 1)
        with self.assertRaises(CalculatorError):
            modulo(5, 0)

    def test_power(self):
        self.assertEqual(power(2, 3), 8)
        self.assertEqual(power(9, 0.5), 3)

    def test_square_root(self):
        self.assertEqual(square_root(144), 12)
        self.assertEqual(square_root(0), 0)
        with self.assertRaises(CalculatorError):
            square_root(-4)

    def test_percentage(self):
        self.assertEqual(percentage(200, 15), 30)
        self.assertEqual(percentage(50, 100), 50)


class TestMemoryAndHistory(unittest.TestCase):
    """Testes para o sistema de memória e histórico."""

    def test_memory_operations(self):
        calc = Calculator()
        self.assertEqual(calc.memory.recall(), 0)

        calc.memory.store(50)
        self.assertEqual(calc.memory.recall(), 50)

        calc.memory.add(25)
        self.assertEqual(calc.memory.recall(), 75)

        calc.memory.subtract(15)
        self.assertEqual(calc.memory.recall(), 60)

        calc.memory.clear()
        self.assertEqual(calc.memory.recall(), 0)

    def test_history(self):
        calc = Calculator()
        calc.record_history("2 + 2", 4)
        calc.record_history("10 * 5", 50)

        history = calc.get_history()
        self.assertEqual(len(history), 2)
        self.assertEqual(history[0].expression, "2 + 2")
        self.assertEqual(history[0].result, 4)
        self.assertEqual(calc.get_last_result(), 50)

        calc.clear_history()
        self.assertEqual(len(calc.get_history()), 0)
        self.assertIsNone(calc.get_last_result())


class TestSafeEvaluator(unittest.TestCase):
    """Testes para o avaliador seguro com AST."""

    def setUp(self):
        self.evaluator = SafeEvaluator()

    def test_arithmetic_precedence(self):
        # Multiplicação antes da adição
        self.assertEqual(self.evaluator.evaluate("2 + 3 * 4"), 14)
        # Parênteses alterando precedência
        self.assertEqual(self.evaluator.evaluate("(2 + 3) * 4"), 20)
        self.assertEqual(self.evaluator.evaluate("10 - 2 * 3 + 4 / 2"), 6)

    def test_unary_and_negative_numbers(self):
        self.assertEqual(self.evaluator.evaluate("-5 + 10"), 5)
        self.assertEqual(self.evaluator.evaluate("-(3 + 2)"), -5)
        self.assertEqual(self.evaluator.evaluate("+8 * -2"), -16)

    def test_powers_and_visual_operators(self):
        self.assertEqual(self.evaluator.evaluate("2 ^ 3"), 8)
        self.assertEqual(self.evaluator.evaluate("2 ** 3"), 8)
        self.assertEqual(self.evaluator.evaluate("6 × 7"), 42)
        self.assertEqual(self.evaluator.evaluate("15 ÷ 3"), 5)

    def test_functions_and_constants(self):
        self.assertEqual(self.evaluator.evaluate("sqrt(81)"), 9)
        self.assertEqual(self.evaluator.evaluate("abs(-42)"), 42)
        self.assertEqual(self.evaluator.evaluate("round(3.7)"), 4)
        self.assertAlmostEqual(self.evaluator.evaluate("sin(pi / 2)"), 1.0)
        self.assertAlmostEqual(self.evaluator.evaluate("cos(0)"), 1.0)

    def test_division_by_zero(self):
        with self.assertRaises(CalculatorError):
            self.evaluator.evaluate("10 / 0")
        with self.assertRaises(CalculatorError):
            self.evaluator.evaluate("5 / (2 - 2)")

    def test_security_blocks_malicious_code(self):
        # Tentativas de injeção de código devem ser bloqueadas
        with self.assertRaises(CalculatorError):
            self.evaluator.evaluate("__import__('os').system('dir')")
        with self.assertRaises(CalculatorError):
            self.evaluator.evaluate("open('secret.txt')")
        with self.assertRaises(CalculatorError):
            self.evaluator.evaluate("exec('print(1)')")


if __name__ == "__main__":
    unittest.main()
