# Como Publicar a Calculadora Grátis no GitHub Pages

Com o **GitHub Pages**, você ganha um link na internet oficial (ex: `https://seu-usuario.github.io/calculadora/`) e qualquer pessoa em qualquer lugar do planeta pode abrir a calculadora no celular.

Uma vez aberta, o celular salva os arquivos na memória e ela passa a funcionar **100% offline**, inclusive no **Modo Avião**!

---

## Passo a Passo para Publicar (Leva 2 minutos)

1. Crie uma conta gratuita no [GitHub](https://github.com/) (se ainda não tiver).
2. Clique no botão **"+" (New repository)** para criar um novo repositório com o nome `calculadora`.
3. Faça upload dos arquivos desta pasta (`docs/` ou todo o projeto) para o repositório.
4. No GitHub, vá na aba **Settings (Configurações)** do seu repositório:
   - No menu lateral esquerdo, clique em **Pages**.
   - Em **Build and deployment > Source**, selecione **Deploy from a branch**.
   - Em **Branch**, escolha `main` e a pasta `/docs` (ou `/root`).
   - Clique em **Save**.
5. Em menos de 1 minuto, o GitHub vai gerar o seu link oficial:
   ```
   https://seu-usuario.github.io/calculadora/
   ```

---

## Como Usar no Celular

1. Envie esse link no WhatsApp para qualquer pessoa.
2. Ao abrir o link no celular, toque no menu do navegador e escolha:
   - **No Android:** "Instalar aplicativo" ou "Adicionar à tela inicial".
   - **No iPhone:** "Adicionar à Tela de Início".
3. A calculadora ganha um ícone e funciona para sempre, mesmo sem internet e sem Wi-Fi!
