"""
Núcleo de regras matemáticas, controle de memória e histórico de operações.
"""

from dataclasses import dataclass
from datetime import datetime
import math
from typing import Any, List, Optional


class CalculatorError(Exception):
    """Exceção base para erros na calculadora."""
    pass


@dataclass
class HistoryEntry:
    """Representa um item no histórico de cálculos."""
    expression: str
    result: float | int
    timestamp: datetime = datetime.now()

    def __str__(self) -> str:
        return f"{self.expression} = {self.result}"


def add(a: float, b: float) -> float | int:
    """Retorna a soma de a e b."""
    return _simplify(a + b)


def subtract(a: float, b: float) -> float | int:
    """Retorna a subtração de a por b."""
    return _simplify(a - b)


def multiply(a: float, b: float) -> float | int:
    """Retorna a multiplicação de a por b."""
    return _simplify(a * b)


def divide(a: float, b: float) -> float | int:
    """Retorna a divisão de a por b. Lança CalculatorError em caso de divisão por zero."""
    if b == 0:
        raise CalculatorError("Erro: Divisão por zero não é permitida.")
    return _simplify(a / b)


def modulo(a: float, b: float) -> float | int:
    """Retorna o resto da divisão de a por b."""
    if b == 0:
        raise CalculatorError("Erro: Módulo por zero não é permitido.")
    return _simplify(a % b)


def power(a: float, b: float) -> float | int:
    """Retorna a elevado à potência b."""
    try:
        return _simplify(math.pow(a, b))
    except OverflowError:
        raise CalculatorError("Erro: O resultado da potência é grande demais (Overflow).")
    except ValueError as e:
        raise CalculatorError(f"Erro no cálculo de potência: {e}")


def square_root(a: float) -> float | int:
    """Retorna a raiz quadrada de a. Lança CalculatorError para valores negativos."""
    if a < 0:
        raise CalculatorError("Erro: Raiz quadrada de número negativo não é suportada nos números reais.")
    return _simplify(math.isqrt(int(a)) if a.is_integer() and math.isqrt(int(a)) ** 2 == int(a) else math.sqrt(a))


def percentage(base: float, percent: float) -> float | int:
    """Calcula a porcentagem dada uma base e o percentual."""
    return _simplify((base * percent) / 100.0)


def _simplify(value: float) -> float | int:
    """Converte números com casas decimais nulas para inteiros para apresentação mais limpa."""
    if isinstance(value, float) and value.is_integer():
        return int(value)
    return round(value, 10)


class Memory:
    """Gerencia as operações de memória (M+, M-, MR, MC)."""

    def __init__(self) -> None:
        self._value: float = 0.0

    def recall(self) -> float | int:
        """Retorna o valor armazenado na memória (MR)."""
        return _simplify(self._value)

    def store(self, value: float) -> None:
        """Define o valor da memória (MS)."""
        self._value = float(value)

    def add(self, value: float) -> None:
        """Adiciona um valor à memória (M+)."""
        self._value += float(value)

    def subtract(self, value: float) -> None:
        """Subtrai um valor da memória (M-)."""
        self._value -= float(value)

    def clear(self) -> None:
        """Zera o valor da memória (MC)."""
        self._value = 0.0

    @property
    def has_value(self) -> bool:
        """Indica se a memória possui valor diferente de zero."""
        return self._value != 0.0


class Calculator:
    """Classe principal de cálculo que integra histórico e memória."""

    def __init__(self) -> None:
        self.memory: Memory = Memory()
        self.history: List[HistoryEntry] = []

    def record_history(self, expression: str, result: float | int) -> HistoryEntry:
        """Registra uma operação no histórico."""
        entry = HistoryEntry(expression=expression, result=result)
        self.history.append(entry)
        return entry

    def get_history(self) -> List[HistoryEntry]:
        """Retorna a lista completa de histórico."""
        return list(self.history)

    def clear_history(self) -> None:
        """Limpa o histórico de cálculos."""
        self.history.clear()

    def get_last_result(self) -> Optional[float | int]:
        """Retorna o resultado da última operação executada, se houver."""
        if self.history:
            return self.history[-1].result
        return None
