"""
Avaliador seguro de expressões matemáticas baseado na Árvore Sintática Abstrata (AST).
Impede a execução de comandos arbitrários e garante avaliação matemática estrita.
"""

import ast
import math
import operator
from typing import Any, Callable, Dict

from .core import CalculatorError, _simplify


class SafeEvaluator:
    """Avaliador seguro de expressões numéricas via AST."""

    # Operadores binários suportados
    _BINARY_OPERATORS: Dict[type, Callable[[Any, Any], Any]] = {
        ast.Add: operator.add,
        ast.Sub: operator.sub,
        ast.Mult: operator.mul,
        ast.Div: operator.truediv,
        ast.FloorDiv: operator.floordiv,
        ast.Mod: operator.mod,
        ast.Pow: operator.pow,
    }

    # Operadores unários suportados (+a, -a)
    _UNARY_OPERATORS: Dict[type, Callable[[Any], Any]] = {
        ast.UAdd: operator.pos,
        ast.USub: operator.neg,
    }

    # Constantes matemáticas permitidas
    _CONSTANTS: Dict[str, float] = {
        "pi": math.pi,
        "e": math.e,
        "tau": math.tau,
    }

    # Funções matemáticas permitidas
    _FUNCTIONS: Dict[str, Callable[..., Any]] = {
        "sqrt": math.sqrt,
        "cbrt": math.cbrt if hasattr(math, "cbrt") else lambda x: x ** (1 / 3),
        "abs": abs,
        "round": round,
        "sin": math.sin,
        "cos": math.cos,
        "tan": math.tan,
        "log": math.log,
        "log10": math.log10,
        "exp": math.exp,
        "rad": math.radians,
        "deg": math.degrees,
    }

    def evaluate(self, expression: str) -> float | int:
        """
        Analisa e calcula o resultado de uma expressão matemática de texto.

        Exemplos válidos:
            - '2 + 3 * 4'
            - '(10 + 5) / 2'
            - '2 ^ 3' ou '2 ** 3'
            - 'sqrt(16) + 4'
            - 'sin(pi / 2)'
        """
        if not expression or not expression.strip():
            raise CalculatorError("Expressão vazia.")

        sanitized = self._preprocess(expression)

        try:
            tree = ast.parse(sanitized, mode="eval")
        except SyntaxError as err:
            raise CalculatorError(f"Erro de sintaxe na expressão: '{expression}'.") from err

        result = self._eval_node(tree.body)

        if isinstance(result, complex):
            raise CalculatorError("Resultados com números complexos não são suportados.")

        return _simplify(result)

    def _preprocess(self, expr: str) -> str:
        """Limpa e normaliza caracteres usuais de calculadora."""
        cleaned = expr.strip()
        # Converte operadores visuais comuns
        cleaned = cleaned.replace("×", "*").replace("÷", "/")
        # Converte acento circunflexo para exponenciação do Python
        cleaned = cleaned.replace("^", "**")
        # Converte vírgula decimal para ponto se for separador numérico
        # (ex: '3,14' -> '3.14')
        import re
        cleaned = re.sub(r'(\d+),(\d+)', r'\1.\2', cleaned)
        return cleaned

    def _eval_node(self, node: ast.AST) -> Any:
        """Avalia recursivamente os nós da AST."""
        # Suporte para literais numéricos (Python 3.8+)
        if isinstance(node, ast.Constant):
            if isinstance(node.value, (int, float)):
                return node.value
            raise CalculatorError(f"Tipo de valor não suportado: {type(node.value).__name__}")

        # Operações unárias (+5, -10)
        elif isinstance(node, ast.UnaryOp):
            op_type = type(node.op)
            if op_type in self._UNARY_OPERATORS:
                operand = self._eval_node(node.operand)
                return self._UNARY_OPERATORS[op_type](operand)
            raise CalculatorError(f"Operador unário não suportado: {op_type.__name__}")

        # Operações binárias (2 + 3, 4 * 5, etc)
        elif isinstance(node, ast.BinOp):
            op_type = type(node.op)
            if op_type in self._BINARY_OPERATORS:
                left = self._eval_node(node.left)
                right = self._eval_node(node.right)
                
                # Tratamento de divisão/módulo por zero
                if op_type in (ast.Div, ast.FloorDiv, ast.Mod) and right == 0:
                    raise CalculatorError("Erro: Divisão por zero não é permitida.")

                try:
                    return self._BINARY_OPERATORS[op_type](left, right)
                except OverflowError:
                    raise CalculatorError("Erro: Resultado muito grande (Overflow).")
                except ZeroDivisionError:
                    raise CalculatorError("Erro: Divisão por zero não é permitida.")
            raise CalculatorError(f"Operador binário não suportado: {op_type.__name__}")

        # Identificadores (constantes permitidas como pi, e)
        elif isinstance(node, ast.Name):
            name = node.id
            if name in self._CONSTANTS:
                return self._CONSTANTS[name]
            raise CalculatorError(f"Identificador não reconhecido ou não permitido: '{name}'")

        # Chamadas de função permitidas (sqrt, sin, etc)
        elif isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name):
                func_name = node.func.id
                if func_name in self._FUNCTIONS:
                    args = [self._eval_node(arg) for arg in node.args]
                    func = self._FUNCTIONS[func_name]
                    try:
                        return func(*args)
                    except ValueError as err:
                        raise CalculatorError(f"Erro no cálculo de '{func_name}': {err}")
                    except OverflowError:
                        raise CalculatorError(f"Erro: Overflow no cálculo de '{func_name}'.")
                    except TypeError:
                        raise CalculatorError(f"Número incorreto de argumentos para '{func_name}'.")
                raise CalculatorError(f"Função não autorizada ou desconhecida: '{func_name}'")
            raise CalculatorError("Chamada de função complexa não suportada.")

        # Rejeitar explicitamente qualquer outra estrutura AST
        raise CalculatorError(f"Construção sintática não permitida: {type(node).__name__}")
