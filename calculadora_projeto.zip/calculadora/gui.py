"""
Interface Gráfica (GUI) Desktop para a calculadora desenvolvida com Tkinter.
Design moderno com tema escuro, botões ergonômicos e suporte completo ao teclado físico.
"""

import math
import tkinter as tk
from tkinter import messagebox, ttk
from typing import Optional

from .core import Calculator, CalculatorError
from .parser import SafeEvaluator


class CalculatorGUI:
    """Janela principal da calculadora gráfica."""

    # Paleta de cores Alvinegra com Vermelho da Cruz de Malta (Vasco da Gama)
    BG_MAIN = "#0D0E11"
    BG_DISPLAY = "#14151A"
    FG_DISPLAY_EXPR = "#8A8D98"
    FG_DISPLAY_MAIN = "#FFFFFF"

    BTN_NUM_BG = "#1A1B20"
    BTN_NUM_FG = "#FFFFFF"
    BTN_NUM_ACTIVE = "#2B2D34"

    BTN_OP_BG = "#262831"
    BTN_OP_FG = "#FFFFFF"
    BTN_OP_ACTIVE = "#353844"

    BTN_FN_BG = "#1F2026"
    BTN_FN_FG = "#C5C7D0"
    BTN_FN_ACTIVE = "#2E303A"

    # Vermelho da Cruz de Malta
    BTN_EQUALS_BG = "#D40000"
    BTN_EQUALS_FG = "#FFFFFF"
    BTN_EQUALS_ACTIVE = "#B30000"

    BTN_CLEAR_BG = "#2C1516"
    BTN_CLEAR_FG = "#FF6B6B"
    BTN_CLEAR_ACTIVE = "#3D1D1E"

    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title("Calculadora do Heitor ✠ Vasco da Gama")
        self.root.geometry("380x570")
        self.root.minsize(340, 500)
        self.root.configure(bg=self.BG_MAIN)

        self.calculator = Calculator()
        self.evaluator = SafeEvaluator()

        self.current_expr = ""
        self.just_calculated = False

        self._build_ui()
        self._bind_keys()

    def _build_ui(self) -> None:
        """Cria e organiza os componentes da interface visual."""
        # Top Header: Heitor & Vasco
        self.header_frame = tk.Frame(self.root, bg=self.BG_MAIN)
        self.header_frame.pack(fill=tk.X, padx=14, pady=(10, 4))

        self.lbl_title = tk.Label(
            self.header_frame,
            text="✠ Calculadora do Heitor",
            font=("Segoe UI", 11, "bold"),
            bg=self.BG_MAIN,
            fg="#FFFFFF",
        )
        self.lbl_title.pack(side=tk.LEFT)

        self.lbl_subtitle = tk.Label(
            self.header_frame,
            text="Vasco da Gama ✠",
            font=("Segoe UI", 9, "bold"),
            bg=self.BG_MAIN,
            fg="#D40000",
        )
        self.lbl_subtitle.pack(side=tk.RIGHT)

        # Top Frame: Display
        self.display_frame = tk.Frame(self.root, bg=self.BG_DISPLAY, padx=16, pady=16)
        self.display_frame.pack(fill=tk.BOTH, expand=False, padx=12, pady=(4, 6))

        # Linha da expressão anterior / fórmula
        self.lbl_expr = tk.Label(
            self.display_frame,
            text="",
            anchor="e",
            font=("Segoe UI", 12),
            bg=self.BG_DISPLAY,
            fg=self.FG_DISPLAY_EXPR,
        )
        self.lbl_expr.pack(fill=tk.X)

        # Linha do valor principal / resultado
        self.lbl_result = tk.Label(
            self.display_frame,
            text="0",
            anchor="e",
            font=("Segoe UI", 26, "bold"),
            bg=self.BG_DISPLAY,
            fg=self.FG_DISPLAY_MAIN,
        )
        self.lbl_result.pack(fill=tk.X, pady=(4, 0))

        # Frame da barra de ferramentas rápidas (Histórico e Memória)
        self.toolbar_frame = tk.Frame(self.root, bg=self.BG_MAIN)
        self.toolbar_frame.pack(fill=tk.X, padx=12, pady=(0, 4))

        tool_buttons = [
            ("MC", self._mem_clear),
            ("MR", self._mem_recall),
            ("M+", self._mem_add),
            ("M-", self._mem_sub),
            ("Histórico", self._open_history_window),
        ]

        for text, cmd in tool_buttons:
            btn = tk.Button(
                self.toolbar_frame,
                text=text,
                command=cmd,
                font=("Segoe UI", 9),
                bg=self.BTN_FN_BG,
                fg=self.BTN_FN_FG,
                activebackground=self.BTN_FN_ACTIVE,
                activeforeground=self.BTN_FN_FG,
                relief=tk.FLAT,
                bd=0,
                padx=8,
                pady=2,
                cursor="hand2",
            )
            btn.pack(side=tk.LEFT, padx=2)

        # Frame da grade de botões
        self.grid_frame = tk.Frame(self.root, bg=self.BG_MAIN)
        self.grid_frame.pack(fill=tk.BOTH, expand=True, padx=12, pady=(0, 12))

        # Configuração de redimensionamento proporcional do grid
        for r in range(6):
            self.grid_frame.rowconfigure(r, weight=1)
        for c in range(4):
            self.grid_frame.columnconfigure(c, weight=1)

        # Definição do layout dos botões: (texto, linha, coluna, estilo, comando)
        buttons_layout = [
            # Linha 0: Funções avançadas
            ("(", 0, 0, "fn", lambda: self._append("(")),
            (")", 0, 1, "fn", lambda: self._append(")")),
            ("√", 0, 2, "fn", lambda: self._insert_function("sqrt")),
            ("^", 0, 3, "fn", lambda: self._append("^")),

            # Linha 1: Limpeza e operadores
            ("C", 1, 0, "clear", self._clear_all),
            ("CE", 1, 1, "clear", self._clear_entry),
            ("⌫", 1, 2, "clear", self._backspace),
            ("÷", 1, 3, "op", lambda: self._append("/")),

            # Linha 2: 7, 8, 9, Multiplicação
            ("7", 2, 0, "num", lambda: self._append("7")),
            ("8", 2, 1, "num", lambda: self._append("8")),
            ("9", 2, 2, "num", lambda: self._append("9")),
            ("×", 2, 3, "op", lambda: self._append("*")),

            # Linha 3: 4, 5, 6, Subtração
            ("4", 3, 0, "num", lambda: self._append("4")),
            ("5", 3, 1, "num", lambda: self._append("5")),
            ("6", 3, 2, "num", lambda: self._append("6")),
            ("-", 3, 3, "op", lambda: self._append("-")),

            # Linha 4: 1, 2, 3, Adição
            ("1", 4, 0, "num", lambda: self._append("1")),
            ("2", 4, 1, "num", lambda: self._append("2")),
            ("3", 4, 2, "num", lambda: self._append("3")),
            ("+", 4, 3, "op", lambda: self._append("+")),

            # Linha 5: Inversão de sinal, 0, Ponto, Igual
            ("±", 5, 0, "fn", self._toggle_sign),
            ("0", 5, 1, "num", lambda: self._append("0")),
            (".", 5, 2, "num", lambda: self._append(".")),
            ("=", 5, 3, "equals", self._calculate),
        ]

        for text, r, c, style, command in buttons_layout:
            bg_color, fg_color, active_bg = self._get_button_style(style)
            btn = tk.Button(
                self.grid_frame,
                text=text,
                command=command,
                font=("Segoe UI", 14 if style != "equals" else 16, "bold" if style in ("op", "equals") else "normal"),
                bg=bg_color,
                fg=fg_color,
                activebackground=active_bg,
                activeforeground=fg_color,
                relief=tk.FLAT,
                bd=0,
                cursor="hand2",
            )
            btn.grid(row=r, column=c, padx=3, pady=3, sticky="nsew")

    def _get_button_style(self, style: str) -> tuple[str, str, str]:
        """Retorna as cores correspondentes ao estilo do botão."""
        if style == "num":
            return self.BTN_NUM_BG, self.BTN_NUM_FG, self.BTN_NUM_ACTIVE
        elif style == "op":
            return self.BTN_OP_BG, self.BTN_OP_FG, self.BTN_OP_ACTIVE
        elif style == "fn":
            return self.BTN_FN_BG, self.BTN_FN_FG, self.BTN_FN_ACTIVE
        elif style == "clear":
            return self.BTN_CLEAR_BG, self.BTN_CLEAR_FG, self.BTN_CLEAR_ACTIVE
        elif style == "equals":
            return self.BTN_EQUALS_BG, self.BTN_EQUALS_FG, self.BTN_EQUALS_ACTIVE
        return self.BTN_NUM_BG, self.BTN_NUM_FG, self.BTN_NUM_ACTIVE

    def _bind_keys(self) -> None:
        """Configura atalhos de teclado para uso natural sem necessidade do mouse."""
        self.root.bind("<Key>", self._handle_keypress)
        self.root.bind("<Return>", lambda e: self._calculate())
        self.root.bind("<KP_Enter>", lambda e: self._calculate())
        self.root.bind("<BackSpace>", lambda e: self._backspace())
        self.root.bind("<Escape>", lambda e: self._clear_all())

    def _handle_keypress(self, event: tk.Event) -> None:
        """Filtra e repassa teclas digitadas pelo teclado físico."""
        char = event.char
        if char in "0123456789+-*/()^":
            self._append(char)
        elif char in (",", "."):
            self._append(".")

    def _append(self, value: str) -> None:
        """Adiciona um caractere ou operador à expressão em digitação."""
        # Se acabou de calcular e o usuário digitar um número, recomeça do zero
        if self.just_calculated:
            if value.isdigit() or value == ".":
                self.current_expr = ""
            self.just_calculated = False

        self.current_expr += value
        self._update_display()

    def _insert_function(self, func_name: str) -> None:
        """Insere uma chamada de função com parênteses."""
        if self.just_calculated:
            self.just_calculated = False
        self.current_expr += f"{func_name}("
        self._update_display()

    def _backspace(self) -> None:
        """Remove o último caractere digitado."""
        if self.just_calculated:
            self.just_calculated = False
        self.current_expr = self.current_expr[:-1]
        self._update_display()

    def _clear_all(self) -> None:
        """Limpa toda a tela e reseta o cálculo."""
        self.current_expr = ""
        self.just_calculated = False
        self.lbl_expr.config(text="")
        self.lbl_result.config(text="0")

    def _clear_entry(self) -> None:
        """Limpa apenas a entrada atual."""
        self.current_expr = ""
        self._update_display()

    def _toggle_sign(self) -> None:
        """Inverte o sinal do número atual."""
        if not self.current_expr:
            return
        if self.current_expr.startswith("-"):
            self.current_expr = self.current_expr[1:]
        else:
            self.current_expr = f"-({self.current_expr})"
        self._update_display()

    def _calculate(self) -> None:
        """Executa a avaliação da expressão matemática digitada."""
        if not self.current_expr.strip():
            return

        expression = self.current_expr
        try:
            result = self.evaluator.evaluate(expression)
            self.calculator.record_history(expression, result)

            self.lbl_expr.config(text=f"{expression} =")
            self.lbl_result.config(text=str(result))

            # Prepara para próxima operação usando o resultado obtido
            self.current_expr = str(result)
            self.just_calculated = True
        except CalculatorError as err:
            self.lbl_expr.config(text=expression)
            self.lbl_result.config(text="Erro")
            messagebox.showwarning("Aviso de Cálculo", str(err), parent=self.root)
        except Exception as err:
            self.lbl_expr.config(text=expression)
            self.lbl_result.config(text="Erro")
            messagebox.showerror("Erro", f"Erro inesperado: {err}", parent=self.root)

    def _update_display(self) -> None:
        """Atualiza o visor com a expressão atual."""
        display_text = self.current_expr if self.current_expr else "0"
        self.lbl_result.config(text=display_text)

    # Operações de memória
    def _mem_clear(self) -> None:
        self.calculator.memory.clear()
        messagebox.showinfo("Memória", "Memória limpa (MC).", parent=self.root)

    def _mem_recall(self) -> None:
        val = self.calculator.memory.recall()
        self._append(str(val))

    def _mem_add(self) -> None:
        try:
            val = float(self.lbl_result.cget("text"))
            self.calculator.memory.add(val)
        except ValueError:
            pass

    def _mem_sub(self) -> None:
        try:
            val = float(self.lbl_result.cget("text"))
            self.calculator.memory.subtract(val)
        except ValueError:
            pass

    def _open_history_window(self) -> None:
        """Abre janela com o histórico de cálculos realizados."""
        win = tk.Toplevel(self.root)
        win.title("Histórico de Cálculos")
        win.geometry("320x380")
        win.configure(bg=self.BG_MAIN)
        win.transient(self.root)

        lbl = tk.Label(
            win,
            text="Histórico de Cálculos",
            font=("Segoe UI", 12, "bold"),
            bg=self.BG_MAIN,
            fg=self.FG_DISPLAY_MAIN,
            pady=8,
        )
        lbl.pack(fill=tk.X)

        text_box = tk.Text(
            win,
            bg=self.BG_DISPLAY,
            fg=self.FG_DISPLAY_MAIN,
            font=("Segoe UI", 11),
            bd=0,
            padx=8,
            pady=8,
        )
        text_box.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

        history_items = self.calculator.get_history()
        if not history_items:
            text_box.insert(tk.END, "Nenhum cálculo recente.")
        else:
            for item in history_items:
                text_box.insert(tk.END, f"{item.expression}\n= {item.result}\n\n")

        text_box.config(state=tk.DISABLED)

        btn_clear = tk.Button(
            win,
            text="Limpar Histórico",
            bg=self.BTN_CLEAR_BG,
            fg=self.BTN_CLEAR_FG,
            bd=0,
            pady=6,
            command=lambda: [self.calculator.clear_history(), win.destroy()],
        )
        btn_clear.pack(fill=tk.X, padx=10, pady=10)


def start_gui() -> None:
    """Função de entrada para o modo Gráfico Tkinter."""
    root = tk.Tk()
    app = CalculatorGUI(root)
    root.mainloop()
