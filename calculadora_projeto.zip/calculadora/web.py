"""
Servidor Web Flask para rodar a calculadora no celular e navegadores.
Permite acesso via Wi-Fi pelo celular como um Web App / PWA.
"""

import os
import socket
from flask import Flask, jsonify, render_template, request, send_from_directory

from .core import Calculator, CalculatorError
from .parser import SafeEvaluator

# Diretório base dos templates e estáticos
current_dir = os.path.dirname(os.path.abspath(__file__))
template_dir = os.path.join(current_dir, "templates")
static_dir = os.path.join(current_dir, "static")

app = Flask(__name__, template_folder=template_dir, static_folder=static_dir)

# Instâncias globais da calculadora e avaliador
calculator = Calculator()
evaluator = SafeEvaluator()


def get_local_ip() -> str:
    """Detecta o endereço IP local na rede Wi-Fi/Ethernet."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


@app.route("/")
def index():
    """Página principal da calculadora mobile."""
    return render_template("index.html")


@app.route("/api/calculate", methods=["POST"])
def api_calculate():
    """Endpoint que recebe a expressão e retorna o cálculo via SafeEvaluator."""
    data = request.get_json(force=True, silent=True) or {}
    expression = data.get("expression", "").strip()

    if not expression:
        return jsonify({"success": False, "error": "Expressão vazia"}), 400

    try:
        result = evaluator.evaluate(expression)
        calculator.record_history(expression, result)
        return jsonify({
            "success": True,
            "expression": expression,
            "result": result
        })
    except CalculatorError as e:
        return jsonify({"success": False, "error": str(e)}), 400
    except Exception as e:
        return jsonify({"success": False, "error": f"Erro inesperado: {str(e)}"}), 500


@app.route("/api/history", methods=["GET"])
def api_history():
    """Retorna o histórico de cálculos realizados."""
    history = [
        {"expression": item.expression, "result": item.result}
        for item in calculator.get_history()
    ]
    return jsonify({"history": history})


def start_web(port: int = 5000) -> None:
    """Inicia o servidor web Flask acessível na rede local."""
    local_ip = get_local_ip()
    url_local = f"http://localhost:{port}"
    url_mobile = f"http://{local_ip}:{port}"

    print("\n" + "=" * 60)
    print("      🚀 CALCULADORA WEB / MOBILE INICIADA COM SUCESSO!")
    print("=" * 60)
    print(f" 💻 No seu Computador acesse:  {url_local}")
    print(f" 📱 No seu Celular acesse:     {url_mobile}")
    print("=" * 60)
    print(" Dica para o celular:")
    print("   1. Certifique-se de que o celular está no mesmo Wi-Fi.")
    print(f"   2. Abra o navegador no celular e digite: {url_mobile}")
    print("   3. No menu do Chrome/Safari, toque em 'Adicionar à tela de início'.")
    print("=" * 60 + "\n")

    app.run(host="0.0.0.0", port=port, debug=False)
