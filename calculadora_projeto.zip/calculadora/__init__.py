"""
Pacote Calculadora em Python.
Módulos para cálculos matemáticos, interface de linha de comando e interface gráfica.
"""

from .core import Calculator, CalculatorError
from .parser import SafeEvaluator

__all__ = ["Calculator", "CalculatorError", "SafeEvaluator"]
