"""
Interface de Linha de Comando (CLI) interativa para a calculadora.
"""

import sys
from typing import Optional

from .core import Calculator, CalculatorError
from .parser import SafeEvaluator


BANNER = r"""
======================================================
         ✠ CALCULADORA DO HEITOR - VASCO ✠
               O Gigante da Colina
======================================================
 Digite qualquer expressão matemática para calcular.
 Exemplos:
   > 2 + 2 * 3
   > (15 + 5) / 4
   > 2 ^ 10
   > sqrt(144) + 8
   > ans * 2         (usa o último resultado)

 Comandos especiais:
   ajuda      - Exibe instruções detalhadas
   hist       - Mostra o histórico de cálculos
   memoria    - Exibe o valor salvo na memória
   limpar     - Limpa o histórico atual
   sair       - Encerra a calculadora
======================================================
"""

HELP_TEXT = """
Guia de Operações e Funções:
  +  : Adição                  (ex: 12 + 8)
  -  : Subtração               (ex: 20 - 5)
  *  : Multiplicação           (ex: 6 * 7)
  /  : Divisão                 (ex: 100 / 4)
  // : Divisão inteira         (ex: 7 // 2)
  %  : Módulo (resto)          (ex: 10 % 3)
  ^  : Potência                (ex: 2 ^ 8 ou 2 ** 8)
  ( ): Agrupamento             (ex: (4 + 2) * 3)

Funções matemáticas:
  sqrt(x)  : Raiz quadrada    (ex: sqrt(81) -> 9)
  cbrt(x)  : Raiz cúbica      (ex: cbrt(27) -> 3)
  abs(x)   : Valor absoluto   (ex: abs(-15) -> 15)
  round(x) : Arredondamento   (ex: round(3.7) -> 4)
  sin(x)   : Seno em radianos (ex: sin(pi / 2) -> 1)
  cos(x)   : Cosseno          (ex: cos(0) -> 1)
  tan(x)   : Tangente         (ex: tan(0) -> 0)
  log(x)   : Logaritmo nat.   (ex: log(e) -> 1)
  log10(x) : Logaritmo base 10(ex: log10(100) -> 2)
  rad(deg) : Graus p/ radiano (ex: rad(180) -> 3.1415...)
  deg(rad) : Radiano p/ graus (ex: deg(pi) -> 180)

Variáveis / Constantes:
  pi       : 3.1415926535...
  e        : 2.7182818284...
  ans      : Último resultado calculado
"""


class InteractiveCLI:
    """Controlador da interface de terminal."""

    def __init__(self) -> None:
        self.calculator = Calculator()
        self.evaluator = SafeEvaluator()

    def run(self) -> None:
        """Inicia o loop principal de leitura do usuário."""
        print(BANNER)

        while True:
            try:
                raw_input = input("✠ vasco> ").strip()
            except (KeyboardInterrupt, EOFError):
                print("\nEncerrando a calculadora. Até logo!")
                break

            if not raw_input:
                continue

            command = raw_input.lower()

            if command in ("sair", "exit", "quit", "q"):
                print("Encerrando a calculadora. Até logo!")
                break

            if command in ("ajuda", "help", "h"):
                print(HELP_TEXT)
                continue

            if command in ("hist", "historico", "history"):
                self._show_history()
                continue

            if command in ("limpar", "clear", "cls"):
                self.calculator.clear_history()
                print("Histórico de cálculos limpo com sucesso.\n")
                continue

            if command in ("memoria", "mem", "mr"):
                val = self.calculator.memory.recall()
                print(f"[Memória MR] = {val}\n")
                continue

            if command.startswith("ms "):
                self._handle_memory_store(raw_input[3:])
                continue

            if command == "mc":
                self.calculator.memory.clear()
                print("Memória zerada.\n")
                continue

            # Processamento de cálculo normal
            self._process_expression(raw_input)

    def _process_expression(self, expression: str) -> None:
        """Substitui variáveis especiais e calcula o resultado."""
        expr_to_eval = expression

        # Substitui 'ans' pelo último resultado se houver
        if "ans" in expr_to_eval.lower():
            last_res = self.calculator.get_last_result()
            if last_res is None:
                print("Aviso: 'ans' utilizado, mas nenhum cálculo anterior foi realizado. Usando 0.")
                last_res = 0
            # Substituição insensível a maiúsculas/minúsculas
            import re
            expr_to_eval = re.sub(r'\bans\b', str(last_res), expr_to_eval, flags=re.IGNORECASE)

        try:
            result = self.evaluator.evaluate(expr_to_eval)
            self.calculator.record_history(expression, result)
            print(f"= {result}\n")
        except CalculatorError as err:
            print(f"Erro: {err}\n")
        except Exception as err:
            print(f"Erro inesperado ao calcular: {err}\n")

    def _show_history(self) -> None:
        """Exibe o histórico de cálculos formatado."""
        entries = self.calculator.get_history()
        if not entries:
            print("Nenhum cálculo no histórico ainda.\n")
            return

        print("\n--- Histórico de Cálculos ---")
        for idx, entry in enumerate(entries, start=1):
            ts = entry.timestamp.strftime("%H:%M:%S")
            print(f" [{idx:02d}] {ts} -> {entry.expression} = {entry.result}")
        print("-----------------------------\n")

    def _handle_memory_store(self, value_str: str) -> None:
        """Salva valor especificado na memória."""
        try:
            val = float(value_str.strip().replace(",", "."))
            self.calculator.memory.store(val)
            print(f"Valor {val} salvo na memória (MS).\n")
        except ValueError:
            print("Erro: Valor inválido para salvar na memória.\n")


def start_cli() -> None:
    """Função de entrada para o modo CLI."""
    cli = InteractiveCLI()
    cli.run()
